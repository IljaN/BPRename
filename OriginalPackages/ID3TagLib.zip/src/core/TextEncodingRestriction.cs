namespace ID3TagLib {
    
    public enum TextEncodingRestriction {
        NoRestrictions = 0x00,
        OnlyIsoLatin1OrUtf8 = 0x20
    }
}