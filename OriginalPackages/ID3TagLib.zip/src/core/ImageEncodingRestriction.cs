namespace ID3TagLib {
    
	public enum ImageEncodingRestriction {
		NoRestrictions = 0x00,
		PngOrJpegOnly = 0x04
	}
}