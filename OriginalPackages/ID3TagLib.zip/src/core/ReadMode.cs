
namespace ID3TagLib {
    
    public enum ReadMode {
		ThrowOnError,
		SkipCorruptParts
	}
}