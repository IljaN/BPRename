using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;

[assembly: ComVisibleAttribute(true)] 
[assembly: CLSCompliantAttribute(true)] 
// General Information
[assembly: AssemblyTitle("ID3TagLib")]
[assembly: AssemblyDescription("Library for handling ID3 tags")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Georg Krebelder")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]    

// Version Information
[assembly: AssemblyVersion("0.9.0.*")]

// Signing Information
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]