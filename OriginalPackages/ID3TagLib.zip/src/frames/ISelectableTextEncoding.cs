namespace ID3TagLib {

	public interface ISelectableTextEncoding {
		
		TextEncoding Encoding {
			get;
			set;
		}
	}
}