namespace ID3TagLib {
    
	public enum TimestampFormat: byte {
        AbsoluteTimeInFrames = 0x01,
		AbsoluteTimeInMilliseconds = 0x02
    }
}