
namespace ID3TagLib {
	
	public enum TimestampPrecision {
		Year,
		Month,
		Day,
		Hours,
		Minutes,
		Seconds
	}
}